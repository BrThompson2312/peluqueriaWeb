
document.querySelector("#btnFiltrar").addEventListener("Click", filtrarReservas)

function filtrarReservas(){

}